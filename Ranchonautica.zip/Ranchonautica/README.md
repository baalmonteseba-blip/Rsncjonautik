# Ranchonáutica

App Android que genera una ubicación aleatoria dentro de 10km, priorizando
edificios abandonados, fábricas en desuso, arquitectura hostil y espacios
públicos, con una interfaz estilo Paint.exe psicodélico.

## Cómo abrirlo

1. Abre Android Studio (Koala o más reciente recomendado).
2. `File > Open` y selecciona esta carpeta (`Ranchonautica/`).
3. Deja que Gradle sincronice (bajará automáticamente Compose, Room,
   Retrofit, osmdroid y Play Services Location).
4. Corre en un emulador o dispositivo con **API 26+** y GPS habilitado
   (en el emulador, setea una ubicación falsa desde los "Extended controls").

## Estructura

- `data/LocationGenerator.kt` — genera puntos aleatorios uniformes dentro
  de un radio (usa `sqrt(random)` para no sesgar hacia el centro).
- `data/OverpassService.kt` — consulta OpenStreetMap (Overpass API) buscando
  tags de abandono, industria y arquitectura hostil.
- `data/DestinationEngine.kt` — combina azar + POIs con pesos por categoría;
  reintenta hasta 8 veces antes de rendirse al azar puro.
- `data/HistoryDb.kt` — Room, guarda cada ubicación generada.
- `data/MainViewModel.kt` — obtiene el GPS y orquesta la generación.
- `ui/PaintWidgets.kt` — componentes reutilizables con la estética Paint.exe
  (botones con sombra dura, ventana con barra de título a rayas, paleta lateral).
- `ui/MainScreen.kt` — pantalla principal.

## Pendientes sugeridos

- Pantalla de historial (la entidad y el DAO ya existen en `HistoryDb.kt`,
  falta la UI para listarlos).
- Integrar osmdroid para mostrar el punto en un mapa real en vez de solo
  coordenadas en texto.
- Fuente Comic Sans / pixel font empaquetada en `res/font/` para reforzar
  la estética (por ahora se usa bold del sistema).
- Ajustar radio de búsqueda de POIs (`searchRadiusMeters`) según densidad
  urbana — 400m puede ser poco en zonas rurales.
- Cargar el logo (hoja + texto) como splash screen usando la API
  `SplashScreen` de Android 12+.

## Nota legal

Antes de visitar cualquier ubicación generada (sobre todo edificios
abandonados o industriales), verifica que el acceso sea legal y seguro.
La app no valida propiedad privada ni riesgos estructurales del lugar.
