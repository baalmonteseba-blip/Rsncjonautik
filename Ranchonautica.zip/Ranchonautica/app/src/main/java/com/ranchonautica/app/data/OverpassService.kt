package com.ranchonautica.app.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class OverpassResponse(val elements: List<OverpassElement>)

data class OverpassElement(
    val id: Long,
    val lat: Double?,
    val lon: Double?,
    val type: String,
    val tags: Map<String, String>?
)

interface OverpassApi {
    @GET("interpreter")
    suspend fun query(@Query("data") query: String): OverpassResponse
}

/**
 * Categoría de POI encontrado, usada por el motor de ponderación
 * para decidir qué tan "interesante" es el punto.
 */
enum class PoiCategory { ABANDONADO, FABRICA, HOSTIL, ESPACIO_PUBLICO }

data class Poi(
    val location: LatLng,
    val category: PoiCategory,
    val name: String?
)

object OverpassRepository {

    private val api: OverpassApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://overpass-api.de/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OverpassApi::class.java)
    }

    /**
     * Busca POIs relevantes dentro de [radiusMeters] alrededor de [center].
     * Combina en una sola consulta: edificios/fábricas abandonadas,
     * elementos de arquitectura hostil y espacios públicos.
     */
    suspend fun findNearbyPois(center: LatLng, radiusMeters: Int = 400): List<Poi> {
        val r = radiusMeters
        val lat = center.lat
        val lon = center.lng

        // Tags relevantes por categoría. Overpass QL, formato "around".
        val query = """
            [out:json][timeout:20];
            (
              node["building"~"abandoned|ruins"](around:$r,$lat,$lon);
              way["building"~"abandoned|ruins"](around:$r,$lat,$lon);
              node["disused:building"](around:$r,$lat,$lon);
              way["disused:building"](around:$r,$lat,$lon);
              way["building"="industrial"]["disused"="yes"](around:$r,$lat,$lon);
              way["man_made"="works"]["disused"="yes"](around:$r,$lat,$lon);
              node["barrier"~"spikes|fence"](around:$r,$lat,$lon);
              way["leisure"~"park|garden"](around:$r,$lat,$lon);
              way["amenity"="square"](around:$r,$lat,$lon);
              node["amenity"="square"](around:$r,$lat,$lon);
            );
            out center tags;
        """.trimIndent()

        val response = api.query(query)

        return response.elements.mapNotNull { el ->
            val point = when {
                el.lat != null && el.lon != null -> LatLng(el.lat, el.lon)
                else -> null
            } ?: return@mapNotNull null

            val tags = el.tags ?: emptyMap()
            val category = when {
                tags.containsKey("disused:building") ||
                    tags["building"] in listOf("abandoned", "ruins") -> PoiCategory.ABANDONADO
                tags["building"] == "industrial" || tags["man_made"] == "works" -> PoiCategory.FABRICA
                tags.containsKey("barrier") -> PoiCategory.HOSTIL
                else -> PoiCategory.ESPACIO_PUBLICO
            }

            Poi(point, category, tags["name"])
        }
    }
}
