package com.ranchonautica.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ranchonautica.app.ui.theme.*

/**
 * Botón con el look "3D barato" de Paint: borde negro grueso y una
 * sombra sólida desplazada (no blur), sin elevation nativa.
 */
@Composable
fun PaintButton(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .padding(end = 4.dp, bottom = 4.dp)
    ) {
        // Sombra dura desplazada
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(x = 4.dp, y = 4.dp)
                .background(Negro)
        )
        Box(
            modifier = Modifier
                .background(color)
                .border(3.dp, Negro)
                .clickable(onClick = onClick)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                color = Negro,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }
    }
}

/**
 * Ventana estilo "programa de los 90": barra de título a rayas
 * y controles falsos de minimizar/cerrar.
 */
@Composable
fun PaintWindow(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .background(Magenta)
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(3.dp, Negro)
                .background(
                    Brush.linearGradient(listOf(Cian, Amarillo, Cian))
                )
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, color = Negro, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("[_][□][X]", color = Negro, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        content()
    }
}

/**
 * Paleta lateral tipo caja de colores de Paint, decorativa.
 */
@Composable
fun PaintPalette(modifier: Modifier = Modifier) {
    val swatches = listOf(Rojo, Azul, Amarillo, Magenta, VerdeHoja, Cian)
    Column(
        modifier = modifier
            .background(VerdeHoja)
            .border(3.dp, Negro)
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        swatches.forEach { c ->
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(c, RoundedCornerShape(2.dp))
                    .border(2.dp, Negro)
            )
        }
    }
}
