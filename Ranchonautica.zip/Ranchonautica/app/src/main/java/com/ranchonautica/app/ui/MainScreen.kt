package com.ranchonautica.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ranchonautica.app.data.GenerationState
import com.ranchonautica.app.data.MainViewModel
import com.ranchonautica.app.ui.theme.*

@Composable
fun MainScreen(viewModel: MainViewModel = viewModel()) {
    val state by viewModel.state.collectAsState()

    PaintWindow(
        title = "RANCHONAUTICA.EXE",
        modifier = Modifier.fillMaxSize()
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            PaintPalette(modifier = Modifier.width(48.dp))

            Spacer(Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 260.dp)
                    .border(3.dp, Negro)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Amarillo, Magenta, Violeta, Negro)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (val s = state) {
                    is GenerationState.Idle -> Text(
                        "Toca GENERAR",
                        color = Blanco,
                        fontWeight = FontWeight.Bold
                    )
                    is GenerationState.BuscandoGps -> ColumnCentered("Buscando GPS…")
                    is GenerationState.Generando -> ColumnCentered("Consultando el mapa…")
                    is GenerationState.Listo -> Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Blanco)
                                .border(2.dp, Negro)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "${s.destino.label}\n" +
                                    "${"%.5f".format(s.destino.location.lat)}, " +
                                    "${"%.5f".format(s.destino.location.lng)}",
                                color = Negro,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                    is GenerationState.Error -> Text(
                        s.mensaje,
                        color = Amarillo,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PaintButton(
                text = "GENERAR!!",
                color = Amarillo,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.generarUbicacion() }
            )
            PaintButton(
                text = "HISTORIAL",
                color = Cian,
                modifier = Modifier.weight(1f),
                onClick = { /* TODO: navegar a pantalla de historial */ }
            )
        }
    }
}

@Composable
private fun ColumnCentered(texto: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator(color = Amarillo)
        Spacer(Modifier.height(8.dp))
        Text(texto, color = Blanco, fontWeight = FontWeight.Bold)
    }
}
