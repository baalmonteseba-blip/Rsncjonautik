package com.ranchonautica.app.data

import kotlin.random.Random

data class Destination(
    val location: LatLng,
    val label: String,
    val category: PoiCategory?
)

/**
 * Orquesta la generación: intenta varios puntos aleatorios dentro del radio
 * y se queda con el que caiga cerca de un POI priorizado. Si tras varios
 * intentos no encuentra nada, devuelve un punto puramente al azar.
 */
object DestinationEngine {

    // Pesos relativos: más alto = más probabilidad de ser elegido si compite
    // con otro POI en el mismo intento.
    private val WEIGHTS = mapOf(
        PoiCategory.ABANDONADO to 4,
        PoiCategory.FABRICA to 3,
        PoiCategory.HOSTIL to 2,
        PoiCategory.ESPACIO_PUBLICO to 1
    )

    suspend fun generate(
        userLocation: LatLng,
        radiusMeters: Double = 10_000.0,
        searchRadiusMeters: Int = 400,
        maxAttempts: Int = 8
    ): Destination {
        repeat(maxAttempts) {
            val candidate = LocationGenerator.randomPointInRadius(userLocation, radiusMeters)
            val pois = runCatching {
                OverpassRepository.findNearbyPois(candidate, searchRadiusMeters)
            }.getOrDefault(emptyList())

            if (pois.isNotEmpty()) {
                val chosen = weightedPick(pois)
                return Destination(
                    location = chosen.location,
                    label = chosen.name ?: labelFor(chosen.category),
                    category = chosen.category
                )
            }
        }

        // Sin suerte tras maxAttempts: azar puro dentro del radio completo
        val fallback = LocationGenerator.randomPointInRadius(userLocation, radiusMeters)
        return Destination(fallback, "Punto sin clasificar", null)
    }

    private fun weightedPick(pois: List<Poi>): Poi {
        val totalWeight = pois.sumOf { WEIGHTS[it.category] ?: 1 }
        var roll = Random.nextInt(totalWeight)
        for (poi in pois) {
            val w = WEIGHTS[poi.category] ?: 1
            if (roll < w) return poi
            roll -= w
        }
        return pois.first()
    }

    private fun labelFor(category: PoiCategory): String = when (category) {
        PoiCategory.ABANDONADO -> "Edificio abandonado"
        PoiCategory.FABRICA -> "Fábrica en desuso"
        PoiCategory.HOSTIL -> "Arquitectura hostil"
        PoiCategory.ESPACIO_PUBLICO -> "Espacio público"
    }
}
