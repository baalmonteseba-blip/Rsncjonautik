package com.ranchonautica.app.data

import kotlin.math.*
import kotlin.random.Random

data class LatLng(val lat: Double, val lng: Double)

/**
 * Genera puntos aleatorios distribuidos uniformemente dentro de un círculo
 * de radio [radiusMeters] alrededor de [origin].
 *
 * Importante: no basta con sumar un delta aleatorio a lat/lng, eso sesga
 * los puntos hacia el centro. Hay que muestrear el área, no el radio.
 */
object LocationGenerator {

    private const val EARTH_RADIUS_M = 6_371_000.0

    fun randomPointInRadius(origin: LatLng, radiusMeters: Double): LatLng {
        // Muestreo uniforme en área: r = R * sqrt(random), no r = R * random
        val distance = radiusMeters * sqrt(Random.nextDouble())
        val bearing = Random.nextDouble(0.0, 2 * PI)

        val lat1 = Math.toRadians(origin.lat)
        val lng1 = Math.toRadians(origin.lng)
        val angularDistance = distance / EARTH_RADIUS_M

        val lat2 = asin(
            sin(lat1) * cos(angularDistance) +
                cos(lat1) * sin(angularDistance) * cos(bearing)
        )
        val lng2 = lng1 + atan2(
            sin(bearing) * sin(angularDistance) * cos(lat1),
            cos(angularDistance) - sin(lat1) * sin(lat2)
        )

        return LatLng(Math.toDegrees(lat2), Math.toDegrees(lng2))
    }

    fun distanceMeters(a: LatLng, b: LatLng): Double {
        val lat1 = Math.toRadians(a.lat)
        val lat2 = Math.toRadians(b.lat)
        val dLat = lat2 - lat1
        val dLng = Math.toRadians(b.lng - a.lng)
        val h = sin(dLat / 2).pow(2) + cos(lat1) * cos(lat2) * sin(dLng / 2).pow(2)
        return 2 * EARTH_RADIUS_M * asin(sqrt(h))
    }
}
